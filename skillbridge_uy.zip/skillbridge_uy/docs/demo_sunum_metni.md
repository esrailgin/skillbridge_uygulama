# SkillBridge Demo Sunum Metni

## Açılış
Merhaba, bugün SkillBridge'i yeni mezun, mentor ve İK ekiplerini aynı kariyer gelişim akışında buluşturan bir platform olarak göstereceğim. Amacımız sadece CV yüklemek değil; adayın becerisini, üretimini, mentor sinyalini ve şirket fırsatını tek ölçülebilir hikayede birleştirmek.

## Vizyon, Misyon, Amaç
Vizyonumuz, kariyer başlangıcındaki belirsizliği görünür ve takip edilebilir bir gelişim yoluna çevirmek. Misyonumuz, adayın gerçek kanıtlarını; CV, beceri, GitHub, rozet ve yol haritası çıktılarıyla mentor ve İK tarafına anlaşılır biçimde taşımak. Ürünün amacı, adayın nerede olduğunu, sıradaki adımı ve hangi fırsata hazır olduğunu netleştirmek.

## Öğrenci / Aday Akışı
Öğrenci hesabında Dashboard ile başlıyorum. Burada profil durumu, CV analizi, beceri sayısı, rozetler ve yol haritası ilerlemesi canlı KPI olarak görülüyor. Ardından CV Analizi ekranında belge yükleniyor, Beceriler ekranında piyasa becerileri ekleniyor, Yol Haritası ekranında hedef role göre haftalık adımlar izleniyor. Görsel yol haritası sayesinde adımlar sadece liste değil, ürünleşmiş bir ilerleme haritası gibi takip ediliyor.

## GitHub ve Portfolyo Kanıtı
GitHub ekranında aday repo bağlantısını giriyor. Sistem bağlantıyı portfolyo kanıtı olarak yorumluyor ve adayın teknik üretimini mentor/İK akışına taşımaya hazır hale getiriyor. Bu bölüm demo sırasında adayın sadece iddia değil, üretim gösterdiğini anlatmak için önemli.

## Taleplerim ve Mentor Akışı
Talepler ekranında aday mentor değerlendirmesi ister. Mentor hesabına geçtiğimde aynı akış mentorun bekleyen değerlendirme taleplerini görmesi, CV'yi incelemesi ve aday hakkında not bırakması için özelleşir. Böylece mentor rolü aday ekranının kopyası gibi değil, değerlendirme operasyonu ekranı gibi çalışır.

## İK ve Fırsatlar
İK hesabında Fırsatlar ekranı şirket eşleşmelerini gösterir. Her fırsatta uyum oranı, rol, konum ve Haritada Aç butonu bulunur. Bu bölümde Google Maps bağlantısıyla uygun şirket konumları açılabilir. İK tarafı için ana mesaj: mentor onaylı aday kısa listeye ve görüşmeye taşınır.

## Raporlar
Raporlar ekranı ürünün yönetici özetidir. CV, beceri, rozet, ilerleme ve talep akışı grafiklerle okunur. Bu ekranı sunumda “adayın kariyer karnesi” olarak anlatabilirsin.

## İletişim ve QR
İletişim ekranında ürün, mentor ve İK destek kanalları var. QR butonu canlı QR üretir; sunum sırasında telefondan okutularak demo bağlantısına gidilebilir. Bu, ürünü sadece masaüstünde değil, paylaşılabilir bir deneyim olarak göstermeye yarar.

## Kapanış
SkillBridge'in farkı, kariyer gelişimini tek tek ekranlara bölmek yerine bütünleşik bir kanıt ve karar akışına çevirmesidir. Aday ne yapacağını görür, mentor neyi değerlendireceğini bilir, İK ise hazır adayla doğru fırsatı daha hızlı eşleştirir.
